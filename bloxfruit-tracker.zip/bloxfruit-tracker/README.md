# ThlongPremium — Blox Fruit Stat Tracker

Web dashboard theo dõi nhiều acc Blox Fruits qua executor script.

---

## Cấu trúc project

```
bloxfruit-tracker/
├── api/
│   ├── update.js      ← nhận data từ Lua script (POST)
│   ├── accounts.js    ← trả về danh sách acc (GET)
│   └── delete.js      ← xóa acc (DELETE)
├── public/
│   └── index.html     ← dashboard web
├── tracker.lua        ← Lua script chạy trong executor
├── vercel.json
└── package.json
```

---

## Deploy lên Vercel

### Bước 1 — Push lên GitHub
```bash
git init
git add .
git commit -m "init"
git remote add origin https://github.com/YOUR_USER/bloxfruit-tracker.git
git push -u origin main
```

### Bước 2 — Import vào Vercel
1. Vào [vercel.com](https://vercel.com) → **Add New Project**
2. Import repo vừa push
3. Framework Preset: **Other**
4. Nhấn **Deploy**

### Bước 3 — Tạo KV Store (database)
1. Vào project trên Vercel → tab **Storage**
2. Nhấn **Create Database** → chọn **KV**
3. Đặt tên bất kỳ → **Create**
4. Nhấn **Connect to Project** → chọn project → **Connect**
5. Vercel tự động inject env vars `KV_REST_API_URL`, `KV_REST_API_TOKEN`

### Bước 4 — Đặt API Secret (tùy chọn)
Trong Vercel → **Settings** → **Environment Variables**:
```
API_SECRET = chuỗi_bí_mật_của_bạn
```
Nếu không đặt thì mặc định là `ThlongPremium2024`.

### Bước 5 — Redeploy
Sau khi thêm KV và env vars → **Deployments** → **Redeploy**.

---

## Chạy Lua Script

1. Mở file `tracker.lua`
2. Đổi dòng đầu:
   ```lua
   local API_URL    = "https://TEN_APP_CUA_BAN.vercel.app/api/update"
   local API_SECRET = "chuỗi_bí_mật_của_bạn"
   ```
3. Copy toàn bộ script vào executor → Execute
4. Mỗi 60 giây script tự gửi stat lên web
5. Mở web dashboard để xem — tự refresh mỗi 30 giây

---

## Đổi API Secret

Phải đổi đồng bộ ở **2 chỗ**:
- Biến môi trường `API_SECRET` trên Vercel
- Biến `API_SECRET` trong `tracker.lua`

---

## Local dev (tùy chọn)

```bash
npm install -g vercel
npm install
vercel dev
```

Web chạy tại `http://localhost:3000`

---

## Executor tương thích

| Executor     | Hỗ trợ |
|-------------|---------|
| Synapse X   | ✅      |
| Delta       | ✅      |
| Fluxus      | ✅      |
| Krnl        | ✅      |
| Script-Ware | ✅      |
